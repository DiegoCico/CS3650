[![Open in Codespaces](https://classroom.github.com/assets/launch-codespace-2972f46106e565e64193e422d61a12cf1da4916b45550586e14ef0a7c637dd04.svg)](https://classroom.github.com/open-in-codespaces?assignment_repo_id=18986464)
# Assignment 8: xv6 Hacking

This is the starter code for [Assignment 8]. It contains the full sources of xv6 with minor modifications, as well as some initial test programs to exercise the new system call.

You can also browse the xv6 source code [here][xv6-global].

For compiling xv6, follow the instructions from Lab 10. Note, that the `CFLAGS` Makefile variable has already been adjusted in the version of xv6 provided here.

[Assignment 8]:https://khoury-cs3650.github.io/a08.html
[xv6-global]:https://khoury-cs3650.github.io/l/10/xv6-global/

